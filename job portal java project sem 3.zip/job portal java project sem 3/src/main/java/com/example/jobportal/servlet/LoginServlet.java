package com.example.jobportal.servlet;

import com.example.jobportal.dao.UserDAO;
import com.example.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        try {
            User user = userDAO.findByEmail(email);
            
            // Simple password check (in production, use proper hashing)
            if (user != null && user.getPasswordHash().equals(password)) {
                HttpSession session = req.getSession();
                session.setAttribute("userId", user.getId());
                session.setAttribute("userName", user.getName());
                session.setAttribute("userRole", user.getRole());
                
                // Redirect based on role
                String redirectUrl;
                switch (user.getRole()) {
                    case "ADMIN":
                        redirectUrl = req.getContextPath() + "/admin/users";
                        break;
                    case "EMPLOYER":
                        redirectUrl = req.getContextPath() + "/employer/jobs";
                        break;
                    case "JOBSEEKER":
                        redirectUrl = req.getContextPath() + "/jobseeker/jobs";
                        break;
                    default:
                        redirectUrl = req.getContextPath() + "/";
                }
                resp.sendRedirect(redirectUrl);
            } else {
                resp.sendRedirect(req.getContextPath() + "/login?error=1");
            }
        } catch (Exception e) {
            throw new ServletException("Login error", e);
        }
    }
}
